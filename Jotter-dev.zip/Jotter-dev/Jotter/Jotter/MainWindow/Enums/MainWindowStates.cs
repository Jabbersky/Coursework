﻿namespace Jotter.MainWindow.Enums
{
	public enum MainWindowStates
	{
		NotesShowing,
		NoteViewing,
		NoteEditing
	}
}
