﻿using BL;
using Jotter.MainWindow;
using Jotter.Model;
using Microsoft.Extensions.DependencyInjection;
using Ninject;
using System.Windows;

namespace Jotter
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
