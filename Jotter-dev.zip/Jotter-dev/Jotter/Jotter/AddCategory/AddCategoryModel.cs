﻿namespace Jotter.AddCategory
{
	public class AddCategoryModel
	{
		public string Name { get; set; }
		public string Password { get; set; }
	}
}
