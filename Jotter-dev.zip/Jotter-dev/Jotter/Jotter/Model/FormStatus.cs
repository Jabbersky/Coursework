﻿namespace Jotter.Model
{
	public enum FormStatus
	{
		ClosedManually,
		ClosedDueToActions
	}
}
