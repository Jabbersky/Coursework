﻿namespace Model.Responses
{
	public class ResponseResult
	{
	}
}
