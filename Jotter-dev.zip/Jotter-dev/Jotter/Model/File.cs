﻿using System;
using System.Runtime.Serialization;

namespace Model
{
    public class File
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}
