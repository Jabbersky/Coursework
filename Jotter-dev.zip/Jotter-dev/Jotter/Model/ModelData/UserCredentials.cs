﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model.ModelData
{
	public class UserCredentials
	{
		public User User { get; set; }
		public DateTime LoggedInTime { get; set; }
	}
}
