﻿namespace BL.Serializer.Model
{
	public enum SerializerType
	{
		Xml,
		Json,
		DataContract
	}
}
