﻿namespace BL.Response
{
	public abstract class Response
	{
	}

	public class EmptyResponse : Response
	{
	}
}
