﻿using Model;

namespace BL.Response.Responses
{
	public class RegisterResponse : Response
	{
		public User User { get; set; }
	}
}
