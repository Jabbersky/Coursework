﻿using Model;

namespace BL.Response.Responses
{
	public class LoginResponse : Response
	{
		public User User { get; set; }
	}
}
