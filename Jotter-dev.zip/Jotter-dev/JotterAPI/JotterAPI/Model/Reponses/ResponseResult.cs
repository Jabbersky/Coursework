﻿namespace JotterAPI.Model.Reponses
{
	public class ResponseResult
	{
	}
}
