﻿using System;

namespace JotterAPI.Model.DTOs.Files
{
	public class FileIds
	{
		public Guid FileId { get; set; }
		public Guid UserId { get; set; }
	}
}
