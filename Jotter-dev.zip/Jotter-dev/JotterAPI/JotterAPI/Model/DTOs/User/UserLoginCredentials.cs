﻿namespace JotterAPI.Model.DTOs.User
{
	public class UserLoginCredentials
	{
		public string Email { get; set; }
		public string Password { get; set; }
	}
}
