﻿using System;

namespace JotterAPI.Model.DTOs.Notes
{
	public class CategoryData
	{
		public Guid CategoryId { get; set; }

		public Guid UserId { get; set; }

		public string? CategoryPassword { get; set; }
	}
}
