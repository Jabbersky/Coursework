﻿using System;

namespace JotterAPI.Model.DTOs.Notes
{
	public class NoteId
	{
		public Guid Id { get; set; }

		public Guid UserId { get; set; }
	}
}
