﻿namespace JotterAPI.Model
{
	public class FileSaveData
	{
		public string FileName { get; set; }

		public string Base64File { get; set; }
	}
}
